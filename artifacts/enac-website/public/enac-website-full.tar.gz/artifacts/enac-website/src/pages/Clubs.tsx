import { useState } from "react";
import { motion, AnimatePresence } from "framer-motion";
import { Cpu, Bot, Globe, Shield, Building2, Zap, Cog, X, CheckCircle, LogIn } from "lucide-react";
import { Link } from "wouter";
import { useAuth } from "@/contexts/AuthContext";

const clubs = [
  {
    id: "aiml",
    title: "AI / Machine Learning Club",
    icon: Cpu,
    color: "text-blue-500",
    bg: "bg-blue-500/10",
    border: "border-blue-500/30",
    desc: "Dive into neural networks, deep learning, computer vision, and NLP. Build models that shape the future.",
    details: "Work on real-world ML projects, participate in Kaggle competitions, attend paper reading sessions, and collaborate with peers and faculty on cutting-edge AI research."
  },
  {
    id: "robotics",
    title: "Robotics & IoT Club",
    icon: Bot,
    color: "text-orange-500",
    bg: "bg-orange-500/10",
    border: "border-orange-500/30",
    desc: "Merge hardware and software. Create autonomous bots, smart devices, and explore the Internet of Things.",
    details: "Build robots for competitions, prototype IoT solutions, work with Arduino/Raspberry Pi, and develop automation projects for real-world use cases."
  },
  {
    id: "webdev",
    title: "Web & App Dev Club",
    icon: Globe,
    color: "text-purple-500",
    bg: "bg-purple-500/10",
    border: "border-purple-500/30",
    desc: "Master modern web frameworks, mobile app development, and craft scalable software architectures.",
    details: "Build full-stack web and mobile applications, contribute to open source, participate in hackathons, and learn from industry professionals."
  },
  {
    id: "cyber",
    title: "Cybersecurity Club",
    icon: Shield,
    color: "text-red-500",
    bg: "bg-red-500/10",
    border: "border-red-500/30",
    desc: "Learn ethical hacking, network security, cryptography, and protect systems from modern threats.",
    details: "Participate in CTF competitions, learn penetration testing, study cryptography, and develop security tools for real-world defence scenarios."
  },
  {
    id: "civil",
    title: "Civil & Environmental Eng. Club",
    icon: Building2,
    color: "text-emerald-500",
    bg: "bg-emerald-500/10",
    border: "border-emerald-500/30",
    desc: "Innovate in structural design, smart cities, and sustainable environmental solutions.",
    details: "Design smart structures, work on sustainable development models, analyse environmental data, and collaborate with urban planning initiatives."
  },
  {
    id: "electrical",
    title: "Electronics & Electrical Club",
    icon: Zap,
    color: "text-yellow-500",
    bg: "bg-yellow-500/10",
    border: "border-yellow-500/30",
    desc: "Explore power systems, circuit design, microcontrollers, and renewable energy tech.",
    details: "Design and test electronic circuits, work on energy projects, build microcontroller-based systems, and explore the future of electrical engineering."
  },
  {
    id: "mechanical",
    title: "Mechanical & Aerospace Club",
    icon: Cog,
    color: "text-slate-500",
    bg: "bg-slate-500/10",
    border: "border-slate-500/30",
    desc: "Design machines, understand aerodynamics, thermodynamics, and advanced manufacturing.",
    details: "Work on mechanical design projects, simulate aerodynamic models, explore 3D printing/CAD, and engage in manufacturing and materials research."
  }
];

function ClubModal({ club, onClose }: { club: typeof clubs[0]; onClose: () => void }) {
  const { user } = useAuth();
  const [joined, setJoined] = useState(() => {
    return localStorage.getItem(`enac-member-${club.id}`) === "true";
  });

  const handleJoin = () => {
    if (!user) return;
    localStorage.setItem(`enac-member-${club.id}`, "true");
    setJoined(true);
  };

  return (
    <motion.div
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      exit={{ opacity: 0 }}
      className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/50 backdrop-blur-sm"
      onClick={onClose}
    >
      <motion.div
        initial={{ scale: 0.9, opacity: 0 }}
        animate={{ scale: 1, opacity: 1 }}
        exit={{ scale: 0.9, opacity: 0 }}
        className="bg-card border border-border rounded-3xl p-8 max-w-lg w-full shadow-2xl"
        onClick={(e) => e.stopPropagation()}
      >
        <div className="flex items-start justify-between mb-6">
          <div className={`w-14 h-14 rounded-2xl ${club.bg} flex items-center justify-center`}>
            <club.icon className={`w-7 h-7 ${club.color}`} />
          </div>
          <button
            onClick={onClose}
            className="p-2 rounded-full hover:bg-secondary transition-colors text-muted-foreground"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        <h2 className="text-2xl font-bold text-foreground mb-3">{club.title}</h2>
        <p className="text-muted-foreground mb-3 leading-relaxed">{club.desc}</p>
        <p className="text-sm text-muted-foreground leading-relaxed mb-8">{club.details}</p>

        {user ? (
          joined ? (
            <div className="flex items-center gap-3 px-6 py-4 rounded-2xl bg-emerald-500/10 border border-emerald-500/30">
              <CheckCircle className="w-5 h-5 text-emerald-500 shrink-0" />
              <div>
                <p className="text-emerald-600 dark:text-emerald-400 font-semibold text-sm">You're a member!</p>
                <p className="text-xs text-muted-foreground mt-0.5">Welcome to the {club.title}.</p>
              </div>
            </div>
          ) : (
            <button
              onClick={handleJoin}
              className={`w-full py-3.5 rounded-2xl font-semibold text-sm text-white bg-primary hover:opacity-90 active:scale-95 transition-all shadow-lg shadow-primary/25`}
            >
              Become a Member
            </button>
          )
        ) : (
          <div className="space-y-3">
            <p className="text-sm text-muted-foreground text-center">
              You need to sign in to become a member
            </p>
            <Link href="/login">
              <button className="w-full flex items-center justify-center gap-2 py-3.5 rounded-2xl font-semibold text-sm text-white bg-primary hover:opacity-90 active:scale-95 transition-all shadow-lg shadow-primary/25">
                <LogIn className="w-4 h-4" />
                Sign In / Sign Up to Join
              </button>
            </Link>
          </div>
        )}
      </motion.div>
    </motion.div>
  );
}

export default function Clubs() {
  const [selectedClub, setSelectedClub] = useState<typeof clubs[0] | null>(null);
  const { user } = useAuth();

  return (
    <div className="min-h-screen pt-24 pb-24">
      {/* Header */}
      <section className="py-16 text-center max-w-3xl mx-auto px-4">
        <motion.h1
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          className="text-4xl md:text-5xl font-display font-bold text-foreground mb-6"
        >
          Domain-Specific <br /><span className="text-primary">Technical Clubs</span>
        </motion.h1>
        <motion.p
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.1 }}
          className="text-xl text-muted-foreground"
        >
          ENAC oversees multiple specialised clubs to ensure every engineering student finds their niche and community.
        </motion.p>
        {!user && (
          <motion.p
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            transition={{ delay: 0.2 }}
            className="mt-4 text-sm text-muted-foreground"
          >
            <Link href="/login" className="text-primary font-semibold hover:underline">Sign in</Link>{" "}
            to become a member of any club.
          </motion.p>
        )}
      </section>

      {/* Grid */}
      <section className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
          {clubs.map((club, i) => {
            const isMember = localStorage.getItem(`enac-member-${club.id}`) === "true";
            return (
              <motion.div
                key={club.id}
                initial={{ opacity: 0, y: 30 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ duration: 0.5, delay: i * 0.07 }}
                className="bg-card rounded-3xl p-8 border border-border/60 shadow-lg hover:shadow-xl hover:border-primary/30 transition-all duration-300 group flex flex-col"
              >
                <div className={`w-16 h-16 rounded-2xl ${club.bg} flex items-center justify-center mb-6 group-hover:scale-110 transition-transform duration-300`}>
                  <club.icon className={`w-8 h-8 ${club.color}`} />
                </div>
                <h3 className="text-xl font-bold mb-3 text-foreground">{club.title}</h3>
                <p className="text-muted-foreground leading-relaxed text-sm flex-grow">
                  {club.desc}
                </p>
                <div className="mt-6 flex items-center gap-3">
                  <button
                    onClick={() => setSelectedClub(club)}
                    className="flex-1 py-2.5 rounded-xl border border-border text-sm font-medium text-foreground hover:bg-secondary transition-colors"
                  >
                    Learn More
                  </button>
                  {isMember && user ? (
                    <div className="flex items-center gap-1.5 text-emerald-500 text-sm font-medium">
                      <CheckCircle className="w-4 h-4" />
                      Member
                    </div>
                  ) : (
                    <button
                      onClick={() => setSelectedClub(club)}
                      className="flex-1 py-2.5 rounded-xl bg-primary text-white text-sm font-semibold hover:opacity-90 transition-colors shadow-sm shadow-primary/20"
                    >
                      Join Club
                    </button>
                  )}
                </div>
              </motion.div>
            );
          })}
        </div>
      </section>

      {/* Modal */}
      <AnimatePresence>
        {selectedClub && (
          <ClubModal club={selectedClub} onClose={() => setSelectedClub(null)} />
        )}
      </AnimatePresence>
    </div>
  );
}
