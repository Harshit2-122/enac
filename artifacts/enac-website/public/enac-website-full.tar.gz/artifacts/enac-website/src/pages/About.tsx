import { motion } from "framer-motion";
import { Target, Eye, Flag, CheckCircle2 } from "lucide-react";

export default function About() {
  return (
    <div className="min-h-screen pt-24 pb-20">
      
      {/* Page Header */}
      <section className="bg-muted/30 py-16 border-b border-border/50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <motion.h1 
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            className="text-4xl md:text-5xl font-display font-bold text-foreground mb-6"
          >
            About <span className="text-primary">ENAC</span>
          </motion.h1>
          <motion.p 
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.1 }}
            className="text-xl text-muted-foreground max-w-3xl mx-auto"
          >
            The central, student-driven engineering body working to enhance technical engagement at CURAJ.
          </motion.p>
        </div>
      </section>

      {/* Intro Section */}
      <section className="py-20">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-16 items-center">
            <motion.div 
              initial={{ opacity: 0, x: -30 }}
              whileInView={{ opacity: 1, x: 0 }}
              viewport={{ once: true }}
              className="space-y-6"
            >
              <h2 className="text-3xl font-display font-bold text-foreground">Introduction</h2>
              <p className="text-lg text-muted-foreground leading-relaxed">
                The Central University of Rajasthan (CURAJ) has a strong academic foundation with qualified faculty, diverse student participation, and a well-established institutional framework.
              </p>
              <p className="text-lg text-muted-foreground leading-relaxed">
                However, there exists an opportunity to further strengthen the engineering ecosystem by creating a structured platform that promotes innovation, collaboration, and practical learning among students. To address this, we propose the establishment of the Engineers Network at CURAJ (ENAC).
              </p>
              <p className="text-lg text-muted-foreground leading-relaxed">
                ENAC functions as a central, student-driven engineering body, working in coordination with university administration to enhance technical engagement and innovation culture.
              </p>
            </motion.div>
            <motion.div 
              initial={{ opacity: 0, x: 30 }}
              whileInView={{ opacity: 1, x: 0 }}
              viewport={{ once: true }}
              className="relative"
            >
              <div className="aspect-square max-w-md mx-auto rounded-3xl overflow-hidden shadow-2xl relative">
                <img 
                  src={`${import.meta.env.BASE_URL}images/about-shape.png`} 
                  alt="Abstract modern engineering shape" 
                  className="w-full h-full object-cover"
                />
                <div className="absolute inset-0 bg-gradient-to-tr from-primary/20 to-transparent mix-blend-overlay"></div>
              </div>
              
              {/* Decorative blobs */}
              <div className="absolute -top-10 -right-10 w-32 h-32 bg-accent/20 blur-3xl rounded-full -z-10"></div>
              <div className="absolute -bottom-10 -left-10 w-40 h-40 bg-primary/20 blur-3xl rounded-full -z-10"></div>
            </motion.div>
          </div>
        </div>
      </section>

      {/* Aim & Vision */}
      <section className="py-20 bg-muted/30">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
            <motion.div 
              initial={{ opacity: 0, y: 30 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              className="bg-card p-10 rounded-3xl border border-border shadow-lg"
            >
              <div className="w-16 h-16 rounded-2xl bg-primary/10 flex items-center justify-center mb-8">
                <Target className="w-8 h-8 text-primary" />
              </div>
              <h3 className="text-2xl font-display font-bold mb-4">Our Aim</h3>
              <p className="text-muted-foreground text-lg leading-relaxed">
                To establish a collaborative and innovation-driven engineering ecosystem that complements academic learning with practical exposure, industry interaction, and student-led initiatives.
              </p>
            </motion.div>

            <motion.div 
              initial={{ opacity: 0, y: 30 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ delay: 0.1 }}
              className="bg-card p-10 rounded-3xl border border-border shadow-lg"
            >
              <div className="w-16 h-16 rounded-2xl bg-accent/10 flex items-center justify-center mb-8">
                <Eye className="w-8 h-8 text-accent" />
              </div>
              <h3 className="text-2xl font-display font-bold mb-4">Our Vision</h3>
              <p className="text-muted-foreground text-lg leading-relaxed mb-4">
                To develop ENAC as a platform that fosters:
              </p>
              <ul className="space-y-3">
                {[
                  "Innovation and technical excellence",
                  "Collaborative learning across departments",
                  "Industry and alumni engagement",
                  "Entrepreneurial thinking and problem-solving"
                ].map((item) => (
                  <li key={item} className="flex items-center gap-3 text-muted-foreground">
                    <div className="w-1.5 h-1.5 rounded-full bg-primary shrink-0" />
                    <span>{item}</span>
                  </li>
                ))}
              </ul>
            </motion.div>
          </div>
        </div>
      </section>

      {/* Objectives */}
      <section className="py-24">
        <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-16">
            <h2 className="text-3xl md:text-4xl font-display font-bold mb-4 text-foreground">Key Objectives</h2>
            <div className="w-20 h-1.5 bg-primary mx-auto rounded-full" />
          </div>

          <div className="grid gap-4">
            {[
              "Create a central engineering platform for student engagement",
              "Establish domain specific clubs",
              "Promote technical activities such as hackathons, workshops, and competitions",
              "Encourage hands-on learning and project-based development",
              "Facilitate interaction with industry professionals and alumni",
              "Promote startup and entrepreneurial awareness",
              "Support career development and placement readiness",
              "Organise yearly tech-festivals and events",
              "Establish a structured R&D system in the school of engineering"
            ].map((obj, i) => (
              <motion.div
                key={i}
                initial={{ opacity: 0, x: -20 }}
                whileInView={{ opacity: 1, x: 0 }}
                viewport={{ once: true }}
                transition={{ delay: i * 0.05 }}
                className="flex items-start gap-4 p-4 rounded-xl hover:bg-muted/50 transition-colors"
              >
                <CheckCircle2 className="w-6 h-6 text-primary shrink-0 mt-0.5" />
                <span className="text-lg text-foreground font-medium">{obj}</span>
              </motion.div>
            ))}
          </div>
        </div>
      </section>
    </div>
  );
}
